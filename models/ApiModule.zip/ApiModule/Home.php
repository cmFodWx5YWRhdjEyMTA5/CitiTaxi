<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Home extends CI_Controller {
	function __construct() {
        parent::__construct();
        //$this->load->helper(form,url);
        $this->load->model("AuthModel");        
    }

    public function index()
	{
		$respose["success"] = 0;
		$respose["error"]=400;
		$respose["message"]="Access Denied";
		echo json_encode($respose);
	}

	public function signup()             //signup
	{
		$respose = array("success"=>0,"error"=>0,"message"=>'');
		$table_name = 'users';
		if(isset($_POST['email']) && $_POST['email']!='' && isset($_POST['mobile']) && $_POST['mobile']!='')
		{
			extract($_POST);
			$checkmail   = array("email"=>$email,"user_type"=>0);
			$checkEmail  = $this->AuthModel->checkRows($table_name,$checkmail);		
			$checkMobile = array('mobile' =>$mobile,"user_type"=>0);
			$mobileExist = $this->AuthModel->checkRows($table_name,$checkMobile);	
			if($checkEmail>0)
			{
				$response = array("error"=>1,"message"=>"Email already Exist");
				echo json_encode($response);							}			
			elseif($mobileExist>0)
			{	
				$respose= array("error"=>1,"message"=>"Mobile number has already registered");
				echo json_encode($respose);
			}
			else
			{
				$imagename ='default.jpg';
				if(isset($_FILES['image']))
				{
					$folder_name = 'userimage';
					$imagename   = $this->AuthModel->imageUpload($_FILES['image'],$folder_name);
				}
				if($image_type==1 && $media_image!='')          //when media image isset
			    {
			    	$imagename =  $media_image;
			    }
				$data= array(
					"ref_code"      =>$this->AuthModel->radomno(6),
					"fb_id"         =>$fb_id,
					"google_id"     =>$google_id,
					"device_token"  =>$device_token,
					"user_type"		=>$user_type,           //0=customer, 1= driver
					"name"			=>$name,
					"dob"			=>$dob,
					"gender"        =>$gender,
					"mobile"		=>$mobile,
					"email"			=>$email,
					"password"		=>md5($password),
					"image"			=>$imagename,
					"image_type"	=>$image_type, 			//0=normal, 1=media
					"activeStatus"  =>$activeStatus,        //Active, Inactive
					"device_type"	=>$device_type         //0=android, 1=ios
					);
				
				if($uid = $this->AuthModel->singleInsert($table_name,$data))
				{					
					$this->AuthModel->user_score($uid,0); //save for score
					$where 			= array("id"=>$uid);
					$record 		= $this->AuthModel->getSingleRecord($table_name,$where);
					$dataResponse   = $this->AuthModel->keychange($record);
					$respose["success"] = 1;
					$respose["message"] = "success";
					$respose["data"]    = $dataResponse;
					echo json_encode($respose);
				}
				else
				{
					$respose["error"] = 1;
					$respose["message"] = "Error occur! Please try again";
					$respose["data"]    = '';
					echo json_encode($respose);
				}		
			}
		}
		else
		{
			$this->index();
		}
	}


	public function login()
	{
		//Login type = 0=>simple login, 1= fb_login 2=google login
		//isset param => login_type,device_token,device_type,email,password,mobile,media_id
		$response = array("success" => 0, "error" => 0);
		extract($_REQUEST);
		$table_name = 'users';
    	if(isset($_REQUEST['login_type']) && $_REQUEST['login_type']==0)
    	{
    		if((isset($_REQUEST['login']) && $_REQUEST['login']!=''))
            {

                $checkWhere  = array("mobile"=>$login,"password"=>md5($password),"user_type"=>0);   
                $checkCrediantial = $this->AuthModel->checkRows($table_name,$checkWhere);
                //echo $checkCrediantial;die();
                $activeWhere = array("mobile"=>$login,"user_type"=>0);
                if($checkCrediantial==0)
                {
                    $checkWhere =  array("email"=>$login, "password"=>md5($password),"user_type"=>0); 
                    $activeWhere = array("email"=>$login, "user_type"=>0);
                    $checkCrediantial = $this->AuthModel->checkRows($table_name,$checkWhere);
                } 			
 	   			$data = '';	
				$checkCrediantial = $this->AuthModel->checkRows($table_name,$checkWhere);
 	   			//print_r($activeWhere);die(); 	   			
				if($checkCrediantial>0)
				{
					$this->AuthModel->checkActiveStatus($table_name,$activeWhere);      //Check, User is Active or not by admin;
					$upData     = array("device_token"=>$device_token,"device_type"=>$device_type,'wronglyPassword'=>0);
					$this->AuthModel->updateRecord($checkWhere,$table_name,$upData);
					$data 		= $this->AuthModel->getSingleRecord($table_name,$checkWhere);	
					$dataResponse     = $this->AuthModel->keychange($data);
					$response  = array("success"=>1, "error" => 0,"message"=>"success","data"=>$dataResponse);
					echo json_encode($response);
				}
				else
				{
					$this->AuthModel->passwordAttempt($table_name,$checkWhere);
					$response  = array("error"=>1,"success"=>0,"message"=>"Invalid Crediantial","data"=>'');
					echo json_encode($response);
				}
    		}
    		else{
    			$this->index();
    		}
    	}
    	elseif (isset($_REQUEST['login_type']) && ($_REQUEST['login_type']==1 || $_REQUEST['login_type']=2)) {
    		if(isset($_REQUEST['media_id']) && $_REQUEST['media_id']!='')
    		{    			
    			$user_type	=	0;
 	   			$data = $this->AuthModel->loginViaMedia($media_id,$login,$login_type,$device_token,$device_type,$user_type);
 	   			$dataResponse     = $this->AuthModel->keychange($data);
				$response  = array("success"=>1,"error" => 0,"message"=>"success","data"=>$dataResponse);
				echo json_encode($response);
    		}	
    		else{
    			$this->index();
    		}
    	}
    	else
    	{
    		$this->index();
    	}
	}

	public function BookDriver()
    {
        $rawPostData    = file_get_contents('php://input');
        $jsonData       = json_decode($rawPostData,true);
        //print_r($jsonData);die();
        if(!empty($jsonData) && !empty($jsonData['dropoff']))
        {
            //customer_id,address_type(single,multiple),fromaddress,fromLat,fromLong,toaddress,toLat,toLong,service_type_id, date,time,booking_type(now,later),country,city
            if($jsonData['booking_type']=='later')
            {
                $paramarray = array('later_pickup_date','later_pickup_time');
                $vResponse = $this->AuthModel->checkRequiredParam($paramarray,$jsonData);
                if(isset($vResponse['status']) && $vResponse['status']==0)
                {
                    $response = array("error"=>1,'success'=>0,'message'=>$vResponse['message']);
                    echo json_encode($response);die();
                }
            }                      
            $customer_id            = $jsonData['customer_id'];
            $country                = $jsonData['country'];
            $city_name              = $jsonData['city_name'];
            $service_type_id        = $jsonData['service_type_id'];
            $booking_address_type   = $jsonData['booking_address_type'];  //Single Multiple
            $pickup                 = $jsonData['pickup'];
            $pickupLat              = $jsonData['pickupLat'];
            $pickupLong             = $jsonData['pickupLong'];
            $dropoff                = $jsonData['dropoff'];
            $date                   = $jsonData['date'];
            $time                   = $jsonData['time'];
            $total_ride_time        = $jsonData['total_ride_time'];
            $total_ride_distance    = $jsonData['total_ride_distance'];
            $total_regular_charge   = $jsonData['total_regular_charge'];
            $total_perminute_charge = $jsonData['total_perminute_charge'];
            $total_fair             = $jsonData['total_fair'];
            $booking_type           = $jsonData['booking_type'];     //(now,later)
            $later_pickup_date      = $jsonData['later_pickup_date']; 
            $later_pickup_time      = $jsonData['later_pickup_time']; 
            $booking_note           = $jsonData['booking_note'];
            $payment_type           = $jsonData['payment_type'];    //cash,paypal,citipay           

            //=================================================================================================//
            
            $fairDetails            = $this->AuthModel->getSingleRecord('fare',array("serviceType_id"=>$service_type_id,"country"=>$country,"city"=>$city_name));  
            //check service available in this city or not
            if(!empty($fairDetails))
            {
                if($jsonData['booking_type']=='later'){
                    $nearbyDriver = true;
                    $driver_id    = 0;
                    $booking_status=8; // will assign later
                    $later_pickup = $later_pickup_date.' '.$later_pickup_time;
                    $later_pickup_string = strtotime($later_pickup);
                    $later_pickup_at = date('d-m-Y h:i A',strtotime($later_pickup));
                }
                else{ 
                    $nearbyDriver = '';
                    $allDriverNearBy  = $this->BookingModel->searchNearByDriver($pickupLat,$pickupLong,$date,$time,$service_type_id);
                    //print_r($allDriverNearBy);die();
                    if(!empty($allDriverNearBy))
                    {
                        foreach ($allDriverNearBy as $near) {
                            $driver = $near->user_id;
                            $nearly  = $this->BookingModel->searchDriver($pickupLat,$pickupLong,$date,$time,$service_type_id,$driver); 
                            //echo json_encode($nearbyDriver);die();
                            if(!empty($nearly)){                                                        
                                $driver_id = $nearly->id;                                
                                $booking_status=0; //assign driver
                                $later_pickup_at ='';
                                $later_pickup_string = '';
                                //print_r($this->db->last_query());die();
                                if($nearly->destination_status=='on')
                                {   
                                    //echo $driver_id;
                                    if($this->checkDriverDestinations($driver_id,$dropoff))
                                    { 
                                        $nearbyDriver = $nearly;
                                        goto getfinaldriver;
                                        break;
                                        //$nearbyDriver = $nearbyDriver;//echo $driver_id;
                                        //exit();
                                    }                                    
                                }
                                else{
                                    $nearbyDriver = $nearly;
                                } 

                            }                            
                        }//echo 'mil gya'.$driver_id;                                                
                    }
                }
                getfinaldriver:
                //echo json_encode($nearbyDriver);die();
                if(!empty($nearbyDriver))
                {                                         
                    $booking_at = $date.' '.$time;                   
                    $bookingData =  array(
                            "customer_id"=>$customer_id,
                            "driver_id"=>$driver_id,
                            "service_typeid"=>$service_type_id,
                            "country"=>$country,
                            "city"=>$city_name,
                            "booking_address_type"=>$booking_address_type,
                            "pickup"=>$pickup,
                            "pickupLat"=>$pickupLat,
                            "pickupLong"=>$pickupLong,
                            "booking_note"=>$booking_note,
                            "booking_at" =>$booking_at,
                            "booking_at_string"=>strtotime($booking_at),
                            "booking_type"=>$booking_type,
                            "later_pickup_at"=>$later_pickup_at,
                            "later_pickup_string"=>$later_pickup_string,
                            "total_ride_time"=>$total_ride_time,
                            "total_distance"=>$total_ride_distance,
                            "distance_unit"=>$fairDetails->distanceUnit,
                            "total_fare"=>$total_fair,
                            "currency"=>$fairDetails->currency,
                            "payment_type"=>$payment_type, 
                            "booking_status"=>$booking_status,                          
                        );                   
                    //print_r($bookingData);die();                    
                    if($booking_id = $this->AuthModel->singleInsert('booking',$bookingData))
                    {
                        $dropoffs=[];
                        foreach($dropoff as $k =>$v)
                        {
                            $c["booking_id"]    =  $booking_id;
                            $c["dropoff"]       =  $v['dropoff'];
                            $c["dropoffLat"]    =  $v['dropoffLat'];
                            $c["dropoffLong"]   =  $v['dropoffLong'];
                            $dropoffs[]=$c;
                        } 
                        if($this->AuthModel->batchInsert('booking_dropoffs',$dropoffs))
                        {                            
                            $this->saveFairDetails($fairDetails,$booking_id,$date,$time,$booking_address_type,$total_regular_charge,$total_perminute_charge);   //save fair details

                            if($jsonData['booking_type']=='now') // when current booking
                            {                                 
                                /*$commissionData = array("booking_id"=>$booking_id,"driver_id"=>$driver_id,"commission_type"=>$fairDetails->company_comission_type,"commission_rate"=>$fairDetails->company_comission_rate,"commission_at"=>$date.' '.$time);
                                $this->AuthModel->singleInsert('company_booking_commission',$commissionData); */

                                $vehicle = $this->AuthModel->getSingleRecord('vechile_details',array("driver_id"=>$driver_id));//get vehicle details
                                $resdata = $this->AuthModel->keychange($nearbyDriver);
                                $tripData = array(  
                                                    "booking_id"=>$booking_id,
                                                    "driver_id"=>$driver_id,
                                                    "driver_image"=>$resdata->image,
                                                    "driver_name"=>$resdata->name,
                                                    "driver_mobile"=>$resdata->mobile,
                                                    "service_typeid"=>$resdata->typeid,
                                                    "service_name"=>$resdata->servicename,
                                                    "vehicle_id"=>$vehicle->vechileId,
                                                    "vehicle_name"=>$vehicle->brand.' '.$vehicle->sub_brand,
                                                    "vehicle_no"=>$vehicle->number_plate,                 
                                                    "liveaddress"=>$resdata->liveaddress,                                 
                                                    "livelatitude"=>$resdata->latitude,                                               
                                                    "livelongitude"=>$resdata->longitude,
                                                    "pickup"=>$pickup,
                                                    "pickupLat"=>$pickupLat,
                                                    "pickupLong"=>$pickupLong, 
                                                    "free_waiting_minute"=>$fairDetails->regularFreeWaitingMinute,
                                                    "waiting_period"=>$fairDetails->regularWaitingPeriodForCharge,
                                                    "waiting_period_charge"=>$fairDetails->regularWaitingPeriodCharge,
                                                    "currency"=>$fairDetails->currency,                                             
                                                );

                                $response = array('success'=>1,'error'=>0,'message'=>'Booking successfull',"data"=>$tripData,'booking_id'=>$booking_id);
                                echo json_encode($response);
                            }
                            else
                            {
                                $response = array('success'=>1,'error'=>0,'message'=>'Booking successfull',"data"=>'','booking_id'=>$booking_id);
                                echo json_encode($response);
                            }
                        }
                        else{
                            $this->AuthModel->delete_record('booking',array('booking_id'=>$booking_id));
                            $response = array('success'=>0,'error'=>1,'message'=>'Oops! something went wrong, please try again',"data"=>'');
                            echo json_encode($response);                            
                        }
                    }
                    else{
                        $response = array("success"=>0,"error"=>1,"message"=>"Oops! something went wrong, please try again");
                        echo json_encode($response);
                    }
                }
                else{
                    $response = array("success"=>0,"error"=>1,"message"=>"Sorry! No driver found at your pickup location");
                    echo json_encode($response);
                }
            } 
            else{
                $response = array('success'=>0,'error'=>1,'message'=>'Please change location.');
                echo json_encode($response);
            } 
        }
        else{
            $this->index();
        }
    }

    public function checkDriverDestinations($driver_id,$dropoff)
    {
        $des = $this->AuthModel->getSingleRecord('driver_destination',array('driver_id'=>$driver_id));
        if(!empty($des))
        {
            $destinationLat = $des->destination_lat;
            $destinationLng = $des->destination_lng;    
            //print_r($dropoff);die();  
            if(count($dropoff>0)) //if multiple address then check far distance address
            {
                foreach($dropoff as $k =>$v)
                {  
                    $dropoffLat    = $v['dropoffLat'];
                    $dropoffLong   = $v['dropoffLong'];
                    $dist   = $this->BookingModel->distance($destinationLat,$destinationLng,$dropoffLat,$dropoffLong,'k');
                    //$dist   = $this->BookingModel->searchDriverDestination($dropoffLat,$dropoffLong,$driver_id);
                    //echo json_encode($dist);die();
                    //$dist         = $this->BookingModel->GetDrivingDistance($destinationLat,$dropoffLat,$destinationLng,$dropoffLong);
                    //if(!empty($dist)){
                        $r['dist']     = $dist;
                        $r['positon']  = $k; 
                        $r['droplat']      = $dropoffLat; 
                        $r['droplng']      = $dropoffLong; 
                        $r['destLat']      =  $destinationLat;       
                        $r['destLng']      =  $destinationLng;       
                        $dropoffs[]    = $r;
                    //}
                }
                //print_r($dropoffs);die();            
                //print_r($dropoffs);die();
                if(!empty($dropoffs)){
                    $maxDropIndex    = array_search(max($dropoffs),$dropoffs); //get longest address index
                    //echo $maxDropIndex;die();
                    $dropoffLat      = $dropoff[$maxDropIndex]['dropoffLat'];
                    $dropoffLng      = $dropoff[$maxDropIndex]['dropoffLong'];                               
                }
                else{
                    $dropoffLat      = $dropoff[0]['dropoffLat'];
                    $dropoffLng      = $dropoff[0]['dropoffLong'];
                }
            }
            else{
                $dropoffLat      = $dropoff[0]['dropoffLat'];
                $dropoffLng      = $dropoff[0]['dropoffLong'];            
            }
            if($this->BookingModel->searchDriverDestination($dropoffLat,$dropoffLng,$driver_id)){            
                return true;
            }
            else{
                return false;
            }
        }
    } 
    
    public function saveFairDetails($fairDetails,$booking_id,$bookdate,$booktime,$booking_address_type,$total_regular_charge,$total_perminute_charge)  //Book driver part
    {
        $time       = strtotime($bookdate.' '.$booktime);
        $fairdata = array(
            "booking_id"                =>$booking_id,
            "currency"                  =>$fairDetails->currency,            
            "base_fair"                 =>$fairDetails->minbase_fair,
            "mini_distance"             =>$fairDetails->min_distance,
            "mini_distance_fair"        =>$fairDetails->mini_distancefair,
            "regular_charge_distance"   =>$fairDetails->regularChargeEveryDistance,
            "regular_distance_charge"   =>$fairDetails->regularChargeForDistance,
            "total_regular_charge"      =>$total_regular_charge,            
            "free_waiting_minute"       =>$fairDetails->regularFreeWaitingMinute,
            "paid_every_waiting_minute" =>$fairDetails->regularWaitingPeriodForCharge,
            "every_waiting_minute_charge"=>$fairDetails->regularWaitingPeriodCharge,
            );
            if($fairDetails->perMinChargeStatus=='on')
            {
                $fairdata["per_minute"]  =$fairDetails->unitPerMinuteforCharge;
                $fairdata["per_minute_charge"] = $fairDetails->unitPerMinutecharge;
                $fairdata["total_per_minute_charge"]=$total_perminute_charge;
            }
            if($booking_address_type=='Multiple')
            {
                $fairdata["multi_address_charge"]=$fairDetails->multiStopCharge;
            }
            if($fairDetails->morningChargeStatus=='on')
            {   
                $starttime  = strtotime($bookdate.' '.$fairDetails->morningSurchargeTimeStart);
                $endtime    = strtotime($bookdate.' '.$fairDetails->morningSurchargeTimeEnd);
                if($time>$starttime && $time<$endtime)
                {
                    $fairdata["morning_surcharge_unit"] =$fairDetails->morningSurchargeUnit;
                    $fairdata["morning_surcharge"]=$morningSurchargePrice;                    
                }                
            }
            if($fairDetails->eveningChargeStatus=='on')
            {
                $starttime  = strtotime($bookdate.' '.$fairDetails->eveningSurchargeTimeStart);
                $endtime    = strtotime($bookdate.' '.$fairDetails->eveningSurchargeTimeEnd);
                if($time>$starttime && $time<$endtime)
                {                   
                    $fairdata["evening_surcharge_unit"]=$fairDetails->eveningSurchargeUnit;
                    $fairdata["evening_surcharge"]=$fairDetails->eveningSurchargePrice;                    
                }
            }
            if($fairDetails->midNightChargeStatus=='on')
            {
                $starttime  = strtotime($bookdate.' '.$fairDetails->midNightSurchargeTimeStart);
                $endtime    = strtotime("+1 day",strtotime($bookdate.' '.$fairDetails->midNightSurchargeTimeEnd));
                if($time>$starttime && $time<$endtime)
                {
                    $fairdata["midnight_surcharge_unit"]=$fairDetails->midNightSurchargeUnit;
                    $fairdata["midnight_surcharge"]=$fairDetails->midNightSurchargeUnit;                   
                }
            }
        $this->AuthModel->singleInsert('booking_fare',$fairdata);
    }    
}
?>

